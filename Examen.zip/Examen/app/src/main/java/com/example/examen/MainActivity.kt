package com.example.examen

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.databinding.DataBindingUtil
import com.example.examen.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private var meters: Double = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Obtener referencias a los elementos de la vista
        val etMeters = findViewById<EditText>(R.id.etMeters)
        val tvResult = findViewById<TextView>(R.id.tvResult)
        val btnKilometers = findViewById<Button>(R.id.btnKilometers)
        val btnCentimeters = findViewById<Button>(R.id.btnCentimeters)
        val btnMillimeters = findViewById<Button>(R.id.btnMillimeters)

        // Configurar el listener para el EditText
        etMeters.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                meters = s.toString().toDoubleOrNull() ?: 0.0
                tvResult.text = String.format("%.2f metros", meters)
            }
        })

        // Configurar los listeners para los botones
        btnKilometers.setOnClickListener {
            val kilometers = meters / 1000.0
            tvResult.text = String.format("%.2f kilómetros", kilometers)
        }

        btnCentimeters.setOnClickListener {
            val centimeters = meters * 100.0
            tvResult.text = String.format("%.2f centímetros", centimeters)
        }

        btnMillimeters.setOnClickListener {
            val millimeters = meters * 1000.0
            tvResult.text = String.format("%.2f milímetros", millimeters)
        }
    }
}